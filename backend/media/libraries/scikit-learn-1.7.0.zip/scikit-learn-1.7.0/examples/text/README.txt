.. _text_examples:

Working with text documents
----------------------------

Examples concerning the :mod:`sklearn.feature_extraction.text` module.
