============
Документация
============

.. important:: в примерах используется синтаксис Python 3.


.. toctree::
   :maxdepth: 2

   guide
   grammemes
   contributing
