.. _misc:

======
Разное
======

.. toctree::
   :maxdepth: 2

   _changes
   _authors
   api_reference
   2trie
