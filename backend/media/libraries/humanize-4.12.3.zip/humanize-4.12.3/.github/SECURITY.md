# Security policy

Security reports can be made via [Tidelift](https://tidelift.com/security). Tidelift
will coordinate the fix and disclosure.
