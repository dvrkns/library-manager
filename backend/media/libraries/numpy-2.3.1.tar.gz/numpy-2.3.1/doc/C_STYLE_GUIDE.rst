
The "NumPy C Style Guide" at this page has been superseded by
:external+nep:doc:`nep-0045-c_style_guide`
